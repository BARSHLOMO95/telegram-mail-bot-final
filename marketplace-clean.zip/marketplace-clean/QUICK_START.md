# 🚀 התחלה מהירה - Marketplace נקי

## 📥 הורדת הקוד

הקוד הנקי נמצא בתיקייה `/tmp/marketplace-clean/`

## 🆕 העלאה לפרויקט GitHub חדש

### שלב 1: צור repository חדש ב-GitHub

1. היכנס ל-https://github.com/new
2. שם הrepository: `marketplace` (או כל שם שתרצה)
3. **אל תסמן** את "Add README" או "Add .gitignore"
4. לחץ "Create repository"

### שלב 2: העלה את הקוד (בטרמינל)

```bash
# עבור לתיקייה הנקייה
cd /tmp/marketplace-clean

# אתחל Git
git init

# הוסף את כל הקבצים
git add .

# צור commit ראשון
git commit -m "Initial commit - Marketplace website"

# חבר ל-GitHub (שנה את USERNAME ו-REPO)
git remote add origin https://github.com/USERNAME/REPO.git

# דחוף ל-GitHub
git branch -M main
git push -u origin main
```

### שלב 3: פרסם ב-Render.com

1. היכנס ל-https://render.com
2. **New +** → **Web Service**
3. חבר את הrepository החדש שיצרת
4. **הגדרות**:
   ```
   Name: marketplace
   Branch: main
   Build Command: pip install -r requirements.txt
   Start Command: python app.py
   Instance Type: Free
   ```
5. **Create Web Service**
6. המתן 2-3 דקות
7. תקבל קישור: `https://marketplace-xxxx.onrender.com`

## 🎯 זהו! האתר חי

- **דף הבית**: `https://your-app.onrender.com`
- **ממשק ניהול**: `https://your-app.onrender.com/admin`

## 📋 רשימת קבצים (13 קבצים בלבד!)

```
marketplace-clean/
├── app.py                  # שרת Flask (173 שורות)
├── database.py            # SQLite (184 שורות)
├── requirements.txt       # רק Flask + Werkzeug
├── runtime.txt            # Python 3.11.0
├── Procfile              # הרצה ב-Heroku/Render
├── render.yaml           # הגדרות Render
├── README.md             # תיעוד מלא
├── .gitignore            # קבצים להתעלם
├── templates/
│   ├── index.html        # דף הבית
│   ├── admin.html        # ממשק ניהול
│   └── product.html      # עמוד מוצר
└── static/
    ├── js/
    │   └── admin.js      # לוגיקה
    └── uploads/
        └── .gitkeep      # שמור תיקייה
```

**סה"כ**: ~1,300 שורות קוד נקיות, בלי זבל!

## ⚡ הפעלה מקומית (לבדיקה)

```bash
cd /tmp/marketplace-clean
pip install -r requirements.txt
python app.py
```

פתח: http://localhost:5000

## 🎨 מה כלול?

✅ ממשק משתמש מעוצב
✅ ממשק ניהול מלא
✅ העלאת תמונות מרובות
✅ קטגוריות ומוצרים
✅ קישורים לחנות
✅ עיצוב רספונסיבי
✅ תמיכה בעברית (RTL)
✅ מוכן לפריסה

## 🔄 עדכון בעתיד

```bash
cd /tmp/marketplace-clean
git add .
git commit -m "Update"
git push
```

Render יעדכן אוטומטית!

---

**זהו! פרויקט נקי לגמרי ללא קבצים מיותרים** 🎉
