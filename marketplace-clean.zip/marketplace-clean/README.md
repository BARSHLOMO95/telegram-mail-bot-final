# 🛒 Marketplace - קטלוג מוצרים

אתר marketplace מודרני בסגנון יופאו (Youpao) עם ניהול מוצרים מלא.

## ✨ תכונות

- 📦 **ניהול מוצרים וקטגוריות**
- 🖼️ **תמונות מרובות לכל מוצר**
- 🛒 **קישורים ישירים לחנות**
- 👥 **שני ממשקים**: משתמש וניהול
- 📱 **רספונסיבי** - עובד מצוין בנייד
- 🎨 **עיצוב מודרני** עם Bootstrap 5
- 🇮🇱 **תמיכה מלאה בעברית** (RTL)

## 🚀 התקנה מהירה

### 1. התקן תלויות
```bash
pip install -r requirements.txt
```

### 2. הפעל את השרת
```bash
python app.py
```

### 3. גש לאתר
- **דף הבית**: http://localhost:5000
- **ממשק ניהול**: http://localhost:5000/admin

## 📁 מבנה הפרויקט

```
marketplace/
├── app.py              # שרת Flask + API
├── database.py         # מסד נתונים SQLite
├── templates/          # עמודי HTML
│   ├── index.html     # דף הבית
│   ├── admin.html     # ממשק ניהול
│   └── product.html   # עמוד מוצר
├── static/
│   ├── js/
│   │   └── admin.js   # לוגיקה של ניהול
│   └── uploads/       # תמונות
├── requirements.txt    # תלויות Python
├── Procfile           # הגדרות Heroku/Render
└── render.yaml        # הגדרות Render.com
```

## 🌐 פריסה לאינטרנט

### Render.com (מומלץ - חינם!)

1. **הירשם**: https://render.com
2. **New Web Service** → חבר את GitHub
3. **הגדרות**:
   ```
   Build Command: pip install -r requirements.txt
   Start Command: python app.py
   ```
4. Deploy!

### Heroku

```bash
git init
git add .
git commit -m "Initial commit"
heroku create your-app-name
git push heroku main
```

### Railway.app

1. היכנס ל-https://railway.app
2. **New Project** → **Deploy from GitHub**
3. זהו!

## 📖 איך להשתמש

### הוסף קטגוריה
1. היכנס ל-`/admin`
2. טאב "קטגוריות" → "הוסף קטגוריה חדשה"
3. מלא שם ותיאור

### הוסף מוצר
1. טאב "מוצרים" → "הוסף מוצר חדש"
2. בחר קטגוריה
3. מלא פרטים
4. העלה תמונות (ניתן מספר בבת אחת)
5. הוסף קישור לחנות

### צפה באתר
- עבור לדף הבית
- סנן לפי קטגוריות
- לחץ על מוצר לצפייה מלאה

## 🎨 התאמה אישית

### שינוי צבעים
ערוך את הקבצים ב-`templates/`:
```css
:root {
    --primary-color: #ff6b6b;    /* צבע ראשי */
    --secondary-color: #4ecdc4;  /* צבע משני */
}
```

### שינוי פורט
ערוך `app.py`:
```python
port = int(os.environ.get('PORT', 5000))  # שנה ל-8080 וכו'
```

## 💾 מסד נתונים

המערכת משתמשת ב-**SQLite** (קובץ `marketplace.db`).

⚠️ **חשוב**: SQLite לא מתאים לפרודקשן עם Render (נמחק בכל deploy).

**לפרודקשן השתמש ב**:
- PostgreSQL (Render מציע בחינם)
- MongoDB Atlas
- Supabase

## 🔒 אבטחה

⚠️ **המערכת אינה כוללת אימות משתמשים!**

לפני שימוש בפרודקשן הוסף:
- מערכת התחברות לממשק ניהול
- הצפנת סיסמאות
- הגנת CSRF
- ולידציה של קבצים

## 🐛 פתרון בעיות

### השרת לא עולה
```bash
python --version  # ודא Python 3.8+
pip install -r requirements.txt
python app.py
```

### תמונות לא נטענות
```bash
mkdir -p static/uploads
chmod 755 static/uploads
```

### שגיאות ב-Render
בדוק:
1. Build logs ב-Dashboard
2. ודא ש-Start Command הוא: `python app.py`
3. ודא ש-Root Directory ריק

## 📞 תמיכה

יצרת בעיה? פתח issue או שלח לי הודעה!

## 📄 רישיון

MIT License - חופשי לשימוש מסחרי ואישי

---

**נוצר ב-2026 | Python + Flask + Bootstrap**
